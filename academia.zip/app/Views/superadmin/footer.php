 <footer class="footer">
	 <div class="container-fluid">
		 <div class="row">
			 <div class="col-md-6">
				 <?php echo view('superadmin/copyright')?>
			 </div>

		 </div>
	 </div>
</footer>
 2020 - <script>document.write(new Date().getFullYear())</script> &copy; Sam Benia 

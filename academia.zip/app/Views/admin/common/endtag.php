<!-- App js -->
<script src="<?php echo base_url('UBold_v4.1.0')?>/assets/js/app.min.js"></script>

</body>
</html>